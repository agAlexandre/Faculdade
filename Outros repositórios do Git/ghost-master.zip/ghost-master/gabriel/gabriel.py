def divisores(n):
    lst=[]
    for x in range(1,n+1):
        if n%x == 0:
            lst.append(x)

    return lst


            
def primo(n):

    if len(divisores(n))==2:
        print("primo")

    else:
        print("não primo")

def perfeito(lst,n):
    soma=0

    for x in range(1,n):
        if n%x == 0:
            soma=soma+x
    if soma==n:
        print("Numero perfeito ")
    else:
        print("Numero não perfeito")

def main():

    numero=int(input("Insira um numero: "))
    perfeito(divisores(numero),numero)
    
    return primo(numero)
    
main()