'''
Alexandre Gabriel da Silva RA 1801416
Aline Gomes Pineda RA 1801726
'''

def lista_divisores(n):
    divisores=[]
    valor= int(len(n))
    i=True
    while i == True:
        conta=n/valor
        if n%valor==0:
           divisores.append(valor)
           i=True
        else:
            i=False
        return divisores
