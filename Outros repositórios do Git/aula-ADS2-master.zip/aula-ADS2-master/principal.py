def soma (x,y):
    return x+y

def mult (x,y):
    return x*y